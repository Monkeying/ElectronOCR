# ElectronOCR
Cute OCR Toolkits For OSX, Based On Electron,React&amp;Tesseract

# Usage

建议先本机安装下Tesseract,安装时间较长,请耐心等待:
Recommend installing tesseact manually:

```
brew install imagemagick
brew install tesseract --all-languages
```

# RoadMap

- Add Support For Shotcut:添加桌面截图功能
- Add Tesseract Installer:优化Tesseract下载
- Optimize the display of text, add markdown/coding support:优化文本显示